
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kelvinogirisen',
  applicationName: 'udacity-cloud-dev-project',
  appUid: 'D7cp8cQmwTZLFflR96',
  orgUid: 'de5de9b1-c388-4a8e-8a5c-6f004885aba2',
  deploymentUid: '5d7b8f49-289f-46b4-ba6c-6cc578489a2f',
  serviceName: 'udacity-cloud-dev-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'udacity-cloud-dev-project-dev-DeleteProperty', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deleteProperty.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}